# Tableau packaged dashboard

`customer_segmentation_churn.twbx` is the packaged Tableau workbook supplied for this project. It contains:
- The Tableau workbook (`.twb`)
- An embedded Hyper extract
- The dashboard background image asset

The workbook contains 9 worksheets and 2 dashboards.

## Data connection note
The workbook XML still contains the original Windows source folder path:
`C:/Users/pc/Downloads/retail-churn-segmentation/retail-churn-segmentation/data/processed`

The packaged Hyper extract is included, so the workbook has its extract data packaged. If Tableau asks for a file location or if you need to refresh the source data, reconnect the text-file data source to the matching CSVs in `../data/processed/` and refresh the extract.

For the final submission, open the `.twbx` in Tableau Desktop and confirm both dashboards render and all filters work. The file package itself passes ZIP integrity validation.
